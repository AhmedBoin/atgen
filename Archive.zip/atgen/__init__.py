import sys
import os

# Add the atgen directory to the Python path
sys.path.append(os.path.join(os.getcwd(), 'atgen'))