import torch
import torch.nn.functional as F
from torch.optim import AdamW

from atgen.network import ATNetwork
from atgen.utils import BLUE, RESET_COLOR
from atgen.ga import ATGEN

import gymnasium as gym
import warnings

warnings.filterwarnings("ignore", category=DeprecationWarning)

class NeuroEvolution(ATGEN):
    def __init__(self, population_size: int, layers: F.List[int]):
        super().__init__(population_size, layers, activation=torch.nn.ReLU(), last_activation=torch.nn.Softmax(-1), rl_learn=False)

    def fitness_fn(self, model: ATNetwork):
        epochs = 10
        env = gym.make("LunarLander-v2")
        total_reward = 0
        for _ in range(epochs):
            state, info = env.reset()
            while True:
                with torch.no_grad():
                    action = model(torch.FloatTensor(state).unsqueeze(0)).argmax().item()
                next_state, reward, terminated, truncated, info = env.step(action)
                total_reward += reward
                state = next_state
                
                if terminated or truncated:
                    break
        env.close()
        return total_reward / epochs
    
    def store_experiences(self, model: ATNetwork):
        epochs = 10
        env = gym.make("LunarLander-v2")
        for _ in range(epochs):
            state, info = env.reset()
            while True:
                with torch.no_grad():
                    action = model(torch.FloatTensor(state).unsqueeze(0)).argmax().item()
                next_state, reward, terminated, truncated, info = env.step(action)
                self.memory.add(state, action, reward, next_state, terminated or truncated)
                state = next_state
                
                if terminated or truncated:
                    break
        env.close()

    def learn_fn(self, model: ATNetwork):
        epochs = 10
        gamma = 0.80
        optimizer = AdamW(model.parameters(), lr=1e-3)
        for i in range(epochs):
            states, actions, rewards, _, _ = self.memory.sample()
            returns = []
            G = 0
            for reward in reversed(rewards):
                G = reward + gamma * G
                returns.insert(0, G)
            returns = torch.cat(returns)
            returns = (returns - returns.mean()) / (returns.std() + 1e-9)

            policy_loss = []
            for state, action, G in zip(states, actions, returns):
                action_prob = model(state)[action]
                policy_loss.append(-torch.log(action_prob) * G)

            policy_loss = torch.cat(policy_loss).sum()

            optimizer.zero_grad()
            policy_loss.backward()
            optimizer.step()

            if i == (epochs // 2):
                model.prune()
                optimizer = AdamW(model.parameters(), lr=1e-1)

if __name__ == "__main__":
    ne = NeuroEvolution(200, [8, 1, 4])
    for i in range(300):
        print(f"\n--- {BLUE}Generation {i+1}{RESET_COLOR} ---")
        ne.run_generation()